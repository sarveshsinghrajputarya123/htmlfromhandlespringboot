package com.example.htmlsql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HtmlsqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(HtmlsqlApplication.class, args);
	}

}
