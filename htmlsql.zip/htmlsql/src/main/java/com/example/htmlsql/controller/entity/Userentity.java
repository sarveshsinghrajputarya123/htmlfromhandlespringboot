/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.htmlsql.controller.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

/**
 *
 * @author acer
 */
@Entity
public class Userentity {
    
    
     
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
       private int idname;
       private String fname;
	private String lname;
	private String email;
	private String passwd;
	private String dob;
	private String gender;

    public int getIdname() {
        return idname;
    }

    public void setIdname(int idname) {
        this.idname = idname;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPasswd() {
        return passwd;
    }

    public void setPasswd(String passwd) {
        this.passwd = passwd;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Userentity(int idname, String fname, String lname, String email, String passwd, String dob, String gender) {
        this.idname = idname;
        this.fname = fname;
        this.lname = lname;
        this.email = email;
        this.passwd = passwd;
        this.dob = dob;
        this.gender = gender;
    }

    @Override
    public String toString() {
        return "Userentity{" + "idname=" + idname + ", fname=" + fname + ", lname=" + lname + ", email=" + email + ", passwd=" + passwd + ", dob=" + dob + ", gender=" + gender + '}';
    }

     private Userentity() {
    }
   
}
