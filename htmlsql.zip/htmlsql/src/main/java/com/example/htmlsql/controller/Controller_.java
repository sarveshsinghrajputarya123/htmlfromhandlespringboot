
package com.example.htmlsql.controller;
 
import ch.qos.logback.core.model.Model;
import com.example.htmlsql.controller.entity.Userentity;
import com.example.htmlsql.repository.Userrepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;


@Controller
public class Controller_ {
    @Autowired
    private Userrepository userrep;
    @GetMapping("/a")
    public String a(){
        return "index";
    }
     @PostMapping("/register")
	public String userRegistration(@ModelAttribute Userentity user, Model model) {
		System.out.println(user);
                System.out.println(user.getEmail());
		System.out.println(user.getFname());
		System.out.println(user.getGender());
		System.out.println(user.getDob());
		System.out.println(user.getPasswd());
userrep.save(user);
	return "welcome";
	}

}
