package com.example.htmlsql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HtmlsqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
